package Decorator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HamburguerTest {

    @Test
    void deveRetornarPrecoHamburguer() {
        Hamburguer hamburguer = new HamburguerSimples(20.0f);
        assertEquals(20.0f, hamburguer.getPreco());
    }

    @Test
    void deveRetornarPrecoHamburguerComQueijo() {
        Hamburguer hamburguer = new Queijo(new HamburguerSimples(20.0f));
        assertEquals(24.0f, hamburguer.getPreco());
    }

    @Test
    void deveRetornarPrecoHamburguerComSalada() {
        Hamburguer hamburguer = new Salada(new HamburguerSimples(20.0f));
        assertEquals(22.0f, hamburguer.getPreco());
    }

    @Test
    void deveRetornarPrecoHamburguerComBacon() {
        Hamburguer hamburguer = new Bacon(new HamburguerSimples(20.0f));
        assertEquals(21.0f, hamburguer.getPreco());
    }

    @Test
    void deveRetornarIngredientesHamburguer() {
        Hamburguer hamburguer = new HamburguerSimples(20.0f);
        assertEquals("Hambúrguer", hamburguer.getIngredientes());
    }

    @Test
    void deveRetornarIngredientesHamburguerComQueijo() {
        Hamburguer hamburguer = new Queijo(new HamburguerSimples(20.0f));
        assertEquals("Hambúrguer/Queijo", hamburguer.getIngredientes());
    }

    @Test
    void deveRetornarIngredientesHamburguerComSalada() {
        Hamburguer hamburguer = new Salada(new HamburguerSimples(20.0f));
        assertEquals("Hambúrguer/Salada", hamburguer.getIngredientes());
    }

    @Test
    void deveRetornarIngredientesHamburguerComBacon() {
        Hamburguer hamburguer = new Bacon(new HamburguerSimples(20.0f));
        assertEquals("Hambúrguer/Bacon", hamburguer.getIngredientes());
    }

    @Test
    void deveRetornarIngredientesHamburguerCompleto() {
        Hamburguer hamburguer = new Bacon(new Salada(new Queijo(new HamburguerSimples(20.0f))));
        assertEquals("Hambúrguer/Queijo/Salada/Bacon", hamburguer.getIngredientes());
    }
}
