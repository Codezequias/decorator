package Decorator;

public class Bacon extends HamburguerDecorator {

    public Bacon(Hamburguer hamburguer) {
        super(hamburguer);
    }

    public float getPercentualPreco() {
        return 5.0f;
    }

    public String getNomeIngrediente() {
        return "Bacon";
    }
}
