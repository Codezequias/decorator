package Decorator;

public class Salada extends HamburguerDecorator {

    public Salada(Hamburguer hamburguer) {
        super(hamburguer);
    }

    public float getPercentualPreco() {
        return 10.0f;
    }

    public String getNomeIngrediente() {
        return "Salada";
    }
}
